One Video is in .wmv format, the other is in mp4. But they are the same video
